# 🚀 Rogers Green Restaurant Scraper

A scalable restaurant data collection system with dynamic zone management, built with Node.js, PostgreSQL, and Bootstrap 5.

## 🌟 Features

### Core Functionality
- **Dynamic Zone Management** - Add unlimited geographical zones via web interface
- **Google Places API Integration** - Automated restaurant data collection
- **Email Extraction** - Web scraping for restaurant contact information
- **Real-time Dashboard** - Monitor scraping progress and data quality
- **CSV Import/Export** - Bulk zone management and data export
- **Auto-geocoding** - Convert addresses to coordinates automatically

### Advanced Features
- **Zone Templates** - Reusable configurations for different area types
- **Priority System** - Schedule scraping based on zone importance
- **Data Quality Scoring** - Automatic assessment of restaurant data completeness
- **Anti-duplicate System** - Prevents overlapping zones
- **Audit Trail** - Complete history of zone modifications
- **Responsive Design** - Works on desktop, tablet, and mobile

## 🛠️ Tech Stack

### Backend
- **Node.js 18+** with Express.js
- **PostgreSQL** with native SQL (no ORM)
- **EJS** templating engine
- **Google Places API** for restaurant data
- **Puppeteer** for web scraping
- **Winston** for logging

### Frontend
- **Bootstrap 5.3** responsive framework
- **DataTables.js** for interactive tables
- **Chart.js** for data visualization
- **Leaflet.js** for mapping
- **jQuery** for DOM manipulation

### Deployment
- **Nginx** reverse proxy
- **PM2** process management
- **Let's Encrypt** SSL certificates
- **UFW** firewall configuration

## 📋 Prerequisites

- Node.js 18.0 or higher
- PostgreSQL 12 or higher
- Google Places API key
- Domain name (for production)

## 🚀 Quick Start

### 1. Clone and Install

```bash
git clone <repository-url>
cd restaurant-scraper
npm install
```

### 2. Environment Setup

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/restaurant_scraper

# Google APIs
GOOGLE_PLACES_API_KEY=your_google_places_api_key
GOOGLE_GEOCODING_API_KEY=your_google_geocoding_api_key

# Application
DOMAIN=rest-data.rogersgreengroup.com
PORT=3000
```

### 3. Database Setup

```bash
# Create database
createdb restaurant_scraper

# Run schema
psql restaurant_scraper < database/schema-complete.sql

# Seed initial data
npm run seed:zones
npm run seed:templates
```

### 4. Start Development

```bash
npm run dev
```

Visit `http://localhost:3000` for the main dashboard or `http://localhost:3000/admin` for zone management.

## 📊 Initial Zone Configuration

The system comes pre-configured with 23 zones covering NYC metro area and Rockland County:

### NYC Core (5 zones)
- Manhattan, Brooklyn, Queens, Bronx, Staten Island

### NYC Neighbors (8 zones)  
- Jersey City, Hoboken, Yonkers, Long Island City, Williamsburg, Astoria, Flushing, Newark

### Rockland County (10 zones)
- New City, Spring Valley, Suffern, Nyack, Pearl River, Monsey, Nanuet, West Haverstraw, Haverstraw, Stony Point

## 🎯 Zone Management

### Adding New Zones

1. **Via Web Interface**: Go to `/admin/zones/new`
2. **CSV Import**: Use `/admin/zones` → Import CSV
3. **From Templates**: Choose from pre-built zone types

### Zone Templates

Pre-configured templates for different area types:
- **US Metropolitan** - Large cities (15km radius)
- **US Suburban** - Suburban areas (7km radius)  
- **Tourist Area** - Vacation destinations (8km radius)
- **College Town** - University areas (6km radius)
- **Kosher Community** - Orthodox Jewish areas (5km radius)

### Priority System

- **High Priority (1)** - Daily scraping, urban centers
- **Medium Priority (2)** - Weekly scraping, suburban areas
- **Low Priority (3)** - Monthly scraping, rural areas

## 🔧 Configuration

### Search Terms
Customize what types of establishments to find:
```javascript
search_terms: ['restaurant', 'food', 'dining', 'cafe']
```

### Cuisine Focus
Target specific cuisine types:
```javascript
cuisine_focus: ['kosher', 'italian', 'seafood']
```

### Coverage Area
Adjust search radius based on area density:
- **Urban**: 3-8km radius
- **Suburban**: 5-10km radius  
- **Rural**: 8-15km radius

## 📈 Data Quality

The system automatically calculates data quality scores based on:

- **Name** (20 points) - Restaurant name present
- **Address** (15 points) - Physical address available  
- **Phone** (20 points) - Contact phone number
- **Email** (25 points) - Email address found
- **Website** (15 points) - Restaurant website
- **Rating** (5 points) - Google rating available

**Total possible score: 100 points**

## 🔄 Scraping Process

### 1. Google Places Search
- Location-based restaurant discovery
- Multiple search terms per zone
- Cuisine-specific queries
- Price level filtering

### 2. Data Enhancement
- Website extraction from Places data
- Email scraping from restaurant websites
- Social media link detection
- Menu and hours extraction

### 3. Quality Control
- Duplicate detection and removal
- Data validation and scoring
- Geocoding verification
- Business status checking

## 📤 Data Export

### Available Formats
- **CSV** - Spreadsheet compatible
- **JSON** - API/development use
- **Excel** - Business reporting

### Export Options
- **All restaurants** - Complete database
- **By zone** - Specific geographical area
- **Filtered data** - Cuisine type, rating, etc.
- **Email list** - Restaurants with email addresses

## 🚀 Production Deployment

### VPS Setup (Namecheap/DigitalOcean)

```bash
# Run automated setup
chmod +x deployment/setup-vps.sh
./deployment/setup-vps.sh
```

### Manual Deployment

1. **Server Preparation**
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install nginx postgresql nodejs npm -y
```

2. **SSL Certificate**
```bash
sudo certbot --nginx -d rest-data.rogersgreengroup.com
```

3. **Application Setup**
```bash
npm install --production
npm run migrate
pm2 start ecosystem.config.js
```

4. **Nginx Configuration**
```bash
sudo cp deployment/nginx.conf /etc/nginx/sites-available/restaurant-scraper
sudo ln -s /etc/nginx/sites-available/restaurant-scraper /etc/nginx/sites-enabled/
sudo systemctl reload nginx
```

## 🔐 Security Features

- **Helmet.js** - Security headers
- **Rate Limiting** - API abuse prevention  
- **CORS** - Cross-origin request control
- **Input Validation** - SQL injection prevention
- **Session Security** - Secure authentication
- **File Upload Limits** - Prevent abuse

## 📊 Monitoring

### Application Logs
```bash
# View application logs
pm2 logs restaurant-scraper

# View nginx logs  
sudo tail -f /var/log/nginx/access.log
```

### Database Performance
```sql
-- Check active connections
SELECT count(*) FROM pg_stat_activity;

-- Monitor query performance
SELECT query, calls, total_time 
FROM pg_stat_statements 
ORDER BY total_time DESC;
```

### System Resources
```bash
# Check disk usage
df -h

# Monitor memory usage
free -h

# Check CPU usage
htop
```

## 🐛 Troubleshooting

### Common Issues

**Database Connection Error**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check connection string
psql $DATABASE_URL
```

**Google API Quota Exceeded**
- Monitor API usage in Google Cloud Console
- Implement request caching
- Add delays between requests

**Email Scraping Blocked**
- Rotate user agents
- Implement random delays
- Use proxy rotation

### Debug Mode

```bash
# Enable debug logging
NODE_ENV=development npm start

# View detailed logs
tail -f logs/app.log
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support or questions:
- **Email**: support@rogersgreengroup.com
- **Documentation**: Check `/docs` folder
- **Issues**: GitHub Issues page

## 🔮 Future Enhancements

- **Multi-language Support** - Spanish, French markets
- **Review Scraping** - Yelp, TripAdvisor integration
- **Social Media** - Instagram, Facebook data
- **Machine Learning** - Cuisine classification
- **Mobile App** - iOS/Android companion
- **API Endpoints** - Third-party integrations

---

**Built with ❤️ by Rogers Green Group**